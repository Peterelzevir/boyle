# main.py
from telethon import TelegramClient, events, Button
from config import Config
from database.database import Database
from handlers.user_handlers import UserHandlers
from handlers.admin_handlers import AdminHandlers
from utils.expiry_checker import ExpiryChecker
import asyncio
import logging
import sys
import os

# Setup logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

class UserbotBot:
    def __init__(self):
        self.bot = TelegramClient('bot', Config.API_ID, Config.API_HASH)
        self.db = Database(Config.DB_URL)
        self.active_userbots = {}
        
    async def start(self):
        await self.bot.start(bot_token=Config.BOT_TOKEN)
        
        # Initialize handlers
        self.user_handlers = UserHandlers(self.bot, self.db)
        self.admin_handlers = AdminHandlers(self.bot, self.db)
        
        # Start expiry checker
        self.expiry_checker = ExpiryChecker(self.bot, self.db)
        asyncio.create_task(self.expiry_checker.start())
        
        # Register handlers
        self._register_handlers()
        
        logger.info("Bot started!")
        
        # Run the bot
        await self.bot.run_until_disconnected()
        
    def _register_handlers(self):
        # User handlers
        @self.bot.on(events.NewMessage(pattern='/start'))
        async def start_handler(event):
            await self.user_handlers.start_handler(event)
            
        @self.bot.on(events.CallbackQuery(pattern=b'create_userbot'))
        async def create_userbot(event):
            await self.user_handlers.create_userbot_handler(event)
            
        @self.bot.on(events.CallbackQuery(pattern=b'settings_userbot'))
        async def settings(event):
            await self.user_handlers.settings_handler(event)
            
        @self.bot.on(events.CallbackQuery(pattern=b'status'))
        async def status(event):
            await self.user_handlers.status_handler(event)
            
        @self.bot.on(events.CallbackQuery(pattern=b'check_lists'))
        async def check_lists(event):
            await self.user_handlers.check_lists_handler(event)
            
        @self.bot.on(events.CallbackQuery(pattern=b'add_list'))
        async def add_list(event):
            await self.user_handlers.add_list_handler(event)
            
        @self.bot.on(events.CallbackQuery(pattern=b'delete_list'))
        async def delete_list(event):
            await self.user_handlers.delete_list_handler(event)
            
        @self.bot.on(events.CallbackQuery(pattern=b'add_groups'))
        async def add_groups(event):
            await self.user_handlers.add_groups_handler(event)
            
        @self.bot.on(events.CallbackQuery(pattern=b'joined_groups'))
        async def joined_groups(event):
            await self.user_handlers.joined_groups_handler(event)            
            
        @self.bot.on(events.CallbackQuery(pattern=b'list_groups'))
        async def list_groups(event):
            await self.user_handlers.list_groups_handler(event)
            
        @self.bot.on(events.CallbackQuery(pattern=b'delete_group'))
        async def delete_group(event):
            await self.user_handlers.delete_group_handler(event)
            
        @self.bot.on(events.CallbackQuery(pattern=b'send_rc'))
        async def send_rc(event):
            await self.user_handlers.send_rc_handler(event)
            
        # Admin handlers
        @self.bot.on(events.CallbackQuery(pattern=b'admin_panel'))
        async def admin_panel(event):
            await self.admin_handlers.admin_panel_handler(event)
            
        @self.bot.on(events.CallbackQuery(pattern=b'add_admin'))
        async def add_admin(event):
            await self.admin_handlers.add_admin_handler(event)
            
        @self.bot.on(events.CallbackQuery(pattern=b'add_premium'))
        async def add_premium(event):
            await self.admin_handlers.add_premium_handler(event)
            
        @self.bot.on(events.CallbackQuery(pattern=b'broadcast'))
        async def broadcast(event):
            await self.admin_handlers.broadcast_handler(event)
            
        @self.bot.on(events.CallbackQuery(pattern=b'user_list'))
        async def user_list(event):
            await self.admin_handlers.user_list_handler(event)
            
        @self.bot.on(events.CallbackQuery(pattern=b'delete_userbot'))
        async def delete_userbot(event):
            await self.admin_handlers.delete_userbot_handler(event)
            
        # Message handlers for states
        @self.bot.on(events.NewMessage)
        async def handle_messages(event):
            if not event.message.is_private:
                return
                
            user_state = self.user_handlers.user_states.get(event.sender_id)
            if not user_state:
                return
                
            if user_state == "waiting_phone":
                await self.user_handlers.handle_phone_number(event)
            elif user_state == "waiting_code":
                await self.user_handlers.handle_code(event)
            elif user_state == "waiting_message":
                await self.user_handlers.handle_new_message(event)
            elif user_state == "waiting_delay":
                await self.user_handlers.handle_delay_input(event)
            elif user_state == "waiting_group":
                await self.user_handlers.handle_group_input(event)
            elif user_state == "waiting_rc_message":
                await self.user_handlers.handle_rc_message(event)
                
            # Admin states
            admin_state = self.admin_handlers.admin_states.get(event.sender_id)
            if event.sender_id == Config.ADMIN_ID and admin_state:
                if admin_state == "waiting_admin_id":
                    await self.admin_handlers.handle_admin_id(event)
                elif admin_state == "waiting_premium_user":
                    await self.admin_handlers.handle_premium_user(event)
                elif admin_state == "waiting_premium_duration":
                    await self.admin_handlers.handle_premium_duration(event)
                elif admin_state == "waiting_broadcast":
                    await self.admin_handlers.handle_broadcast(event)

if __name__ == '__main__':
    bot = UserbotBot()
    
    try:
        asyncio.run(bot.start())
    except KeyboardInterrupt:
        logger.info("Bot stopped!")