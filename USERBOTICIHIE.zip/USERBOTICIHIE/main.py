# main.py
from telethon import TelegramClient, events, Button
from config import Config
from database.database import Database
from handlers.user_handlers import UserHandlers
from handlers.admin_handlers import AdminHandlers
from utils.expiry_checker import ExpiryChecker
import asyncio
import logging
import sys
import os
import traceback
from datetime import datetime

# Add root folder to PYTHONPATH
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Create logs directory if it doesn't exist
if not os.path.exists('logs'):
    os.makedirs('logs')

# Setup logging with timestamp in filename
log_filename = f'logs/bot_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log'

# Setup logging configuration
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(log_filename, encoding='utf-8')
    ]
)
logger = logging.getLogger(__name__)

class UserbotBot:
    def __init__(self):
        # Initialize with detailed client configuration
        self.bot = TelegramClient(
            'bot_session',
            Config.API_ID,
            Config.API_HASH,
            device_model="Telegram Bot",
            system_version="1.0",
            app_version="1.0",
            timeout=30,
            retry_delay=5,
            auto_reconnect=True
        )
        self.db = Database(Config.DB_NAME)
        self.active_userbots = {}
        self.user_handlers = None
        self.admin_handlers = None
        self.expiry_checker = None
        
    async def start(self):
        try:
            logger.info("Starting bot...")
            await self.bot.start(bot_token=Config.BOT_TOKEN)
            
            if not await self.bot.is_user_authorized():
                logger.error("Bot authorization failed!")
                return
                
            # Get bot information
            me = await self.bot.get_me()
            logger.info(f"Bot started successfully as @{me.username}")
            
            # Initialize handlers
            try:
                self.user_handlers = UserHandlers(self.bot, self.db)
                self.admin_handlers = AdminHandlers(self.bot, self.db)
                logger.info("Handlers initialized successfully")
            except Exception as e:
                logger.error(f"Failed to initialize handlers: {str(e)}")
                return
            
            # Start expiry checker
            try:
                self.expiry_checker = ExpiryChecker(self.bot, self.db)
                asyncio.create_task(self.expiry_checker.start())
                logger.info("Expiry checker started")
            except Exception as e:
                logger.error(f"Failed to start expiry checker: {str(e)}")
            
            # Register handlers
            await self._register_handlers()
            
            # Keep the bot running with ping mechanism
            while True:
                try:
                    await self.bot.ping()
                    await asyncio.sleep(60)
                except Exception as e:
                    logger.error(f"Connection error: {str(e)}")
                    await asyncio.sleep(5)
                    continue
                    
        except Exception as e:
            logger.error(f"Critical error starting bot: {str(e)}\n{traceback.format_exc()}")
            raise
            
    async def _register_handlers(self):
        try:
            # Start command handler
            @self.bot.on(events.NewMessage(pattern='/start'))
            async def start_handler(event):
                try:
                    await self.user_handlers.start_handler(event)
                except Exception as e:
                    logger.error(f"Error in start handler: {str(e)}\n{traceback.format_exc()}")
                    await self._safe_respond(event, "An error occurred. Please try again.")

            # User handlers
            @self.bot.on(events.CallbackQuery(pattern=b'create_userbot'))
            async def create_userbot(event):
                try:
                    await self.user_handlers.create_userbot_handler(event)
                except Exception as e:
                    logger.error(f"Error in create_userbot handler: {str(e)}")
                    await self._safe_respond(event, "Error creating userbot. Please try again.")

            @self.bot.on(events.CallbackQuery(pattern=b'settings_userbot'))
            async def settings(event):
                try:
                    await self.user_handlers.settings_handler(event)
                except Exception as e:
                    logger.error(f"Error in settings handler: {str(e)}")
                    await self._safe_respond(event, "Error accessing settings. Please try again.")

            @self.bot.on(events.CallbackQuery(pattern=b'status'))
            async def status(event):
                try:
                    await self.user_handlers.status_handler(event)
                except Exception as e:
                    logger.error(f"Error in status handler: {str(e)}")
                    await self._safe_respond(event, "Error checking status. Please try again.")

            @self.bot.on(events.CallbackQuery(pattern=b'check_lists'))
            async def check_lists(event):
                try:
                    await self.user_handlers.check_lists_handler(event)
                except Exception as e:
                    logger.error(f"Error in check_lists handler: {str(e)}")
                    await self._safe_respond(event, "Error checking lists. Please try again.")

            @self.bot.on(events.CallbackQuery(pattern=b'add_list'))
            async def add_list(event):
                try:
                    await self.user_handlers.add_list_handler(event)
                except Exception as e:
                    logger.error(f"Error in add_list handler: {str(e)}")
                    await self._safe_respond(event, "Error adding list. Please try again.")

            @self.bot.on(events.CallbackQuery(pattern=b'delete_list'))
            async def delete_list(event):
                try:
                    await self.user_handlers.delete_list_handler(event)
                except Exception as e:
                    logger.error(f"Error in delete_list handler: {str(e)}")
                    await self._safe_respond(event, "Error deleting list. Please try again.")

            @self.bot.on(events.CallbackQuery(pattern=b'add_groups'))
            async def add_groups(event):
                try:
                    await self.user_handlers.add_groups_handler(event)
                except Exception as e:
                    logger.error(f"Error in add_groups handler: {str(e)}")
                    await self._safe_respond(event, "Error adding groups. Please try again.")

            @self.bot.on(events.CallbackQuery(pattern=b'joined_groups'))
            async def joined_groups(event):
                try:
                    await self.user_handlers.joined_groups_handler(event)
                except Exception as e:
                    logger.error(f"Error in joined_groups handler: {str(e)}")
                    await self._safe_respond(event, "Error checking joined groups. Please try again.")

            @self.bot.on(events.CallbackQuery(pattern=b'list_groups'))
            async def list_groups(event):
                try:
                    await self.user_handlers.list_groups_handler(event)
                except Exception as e:
                    logger.error(f"Error in list_groups handler: {str(e)}")
                    await self._safe_respond(event, "Error listing groups. Please try again.")

            @self.bot.on(events.CallbackQuery(pattern=b'delete_group'))
            async def delete_group(event):
                try:
                    await self.user_handlers.delete_group_handler(event)
                except Exception as e:
                    logger.error(f"Error in delete_group handler: {str(e)}")
                    await self._safe_respond(event, "Error deleting group. Please try again.")

            @self.bot.on(events.CallbackQuery(pattern=b'send_rc'))
            async def send_rc(event):
                try:
                    await self.user_handlers.send_rc_handler(event)
                except Exception as e:
                    logger.error(f"Error in send_rc handler: {str(e)}")
                    await self._safe_respond(event, "Error sending RC. Please try again.")

            # Admin handlers
            @self.bot.on(events.CallbackQuery(pattern=b'admin_panel'))
            async def admin_panel(event):
                try:
                    await self.admin_handlers.admin_panel_handler(event)
                except Exception as e:
                    logger.error(f"Error in admin_panel handler: {str(e)}")
                    await self._safe_respond(event, "Error accessing admin panel. Please try again.")

            @self.bot.on(events.CallbackQuery(pattern=b'add_admin'))
            async def add_admin(event):
                try:
                    await self.admin_handlers.add_admin_handler(event)
                except Exception as e:
                    logger.error(f"Error in add_admin handler: {str(e)}")
                    await self._safe_respond(event, "Error adding admin. Please try again.")

            @self.bot.on(events.CallbackQuery(pattern=b'add_premium'))
            async def add_premium(event):
                try:
                    await self.admin_handlers.add_premium_handler(event)
                except Exception as e:
                    logger.error(f"Error in add_premium handler: {str(e)}")
                    await self._safe_respond(event, "Error adding premium user. Please try again.")

            @self.bot.on(events.CallbackQuery(pattern=b'broadcast'))
            async def broadcast(event):
                try:
                    await self.admin_handlers.broadcast_handler(event)
                except Exception as e:
                    logger.error(f"Error in broadcast handler: {str(e)}")
                    await self._safe_respond(event, "Error sending broadcast. Please try again.")

            @self.bot.on(events.CallbackQuery(pattern=b'user_list'))
            async def user_list(event):
                try:
                    await self.admin_handlers.user_list_handler(event)
                except Exception as e:
                    logger.error(f"Error in user_list handler: {str(e)}")
                    await self._safe_respond(event, "Error getting user list. Please try again.")

            @self.bot.on(events.CallbackQuery(pattern=b'delete_userbot'))
            async def delete_userbot(event):
                try:
                    await self.admin_handlers.delete_userbot_handler(event)
                except Exception as e:
                    logger.error(f"Error in delete_userbot handler: {str(e)}")
                    await self._safe_respond(event, "Error deleting userbot. Please try again.")

            # Message handlers for states
            @self.bot.on(events.NewMessage)
            async def handle_messages(event):
                if not event.message.is_private:
                    return
                    
                try:
                    user_state = self.user_handlers.user_states.get(event.sender_id)
                    admin_state = self.admin_handlers.admin_states.get(event.sender_id)
                    
                    if user_state:
                        await self._handle_user_state(event, user_state)
                    elif admin_state and event.sender_id == Config.ADMIN_ID:
                        await self._handle_admin_state(event, admin_state)
                except Exception as e:
                    logger.error(f"Error handling message state: {str(e)}")
                    await self._safe_respond(event, "An error occurred. Please try again.")

            logger.info("All handlers registered successfully!")
            
        except Exception as e:
            logger.error(f"Failed to register handlers: {str(e)}\n{traceback.format_exc()}")
            raise
            
    async def _handle_user_state(self, event, state):
        try:
            if state == "waiting_phone":
                await self.user_handlers.handle_phone_number(event)
            elif state == "waiting_code":
                await self.user_handlers.handle_code(event)
            elif state == "waiting_message":
                await self.user_handlers.handle_new_message(event)
            elif state == "waiting_delay":
                await self.user_handlers.handle_delay_input(event)
            elif state == "waiting_group":
                await self.user_handlers.handle_group_input(event)
            elif state == "waiting_rc_message":
                await self.user_handlers.handle_rc_message(event)
        except Exception as e:
            logger.error(f"Error handling user state {state}: {str(e)}")
            await self._safe_respond(event, "An error occurred. Please try again.")
            raise
            
    async def _handle_admin_state(self, event, state):
        try:
            if state == "waiting_admin_id":
                await self.admin_handlers.handle_admin_id(event)
            elif state == "waiting_premium_user":
                await self.admin_handlers.handle_premium_user(event)
            elif state == "waiting_premium_duration":
                await self.admin_handlers.handle_premium_duration(event)
            elif state == "waiting_broadcast":
                await self.admin_handlers.handle_broadcast(event)
        except Exception as e:
            logger.error(f"Error handling admin state {state}: {str(e)}")
            await self._safe_respond(event, "An error occurred. Please try again.")
            raise

    async def _safe_respond(self, event, message):
        """Safely send response messages with error handling"""
        try:
            if hasattr(event, 'answer'):
                await event.answer(message, alert=True)
            else:
                await event.respond(message)
        except Exception as e:
            logger.error(f"Error sending response: {str(e)}")

if __name__ == '__main__':
    bot = UserbotBot()
    
    try:
        logger.info("Starting bot process...")
        asyncio.run(bot.start())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user!")
    except Exception as e:
        logger.error(f"Bot crashed: {str(e)}\n{traceback.format_exc()}")
    finally:
        # Ensure proper cleanup
        if hasattr(bot, 'bot'):
            if bot.bot.is_connected():
                logger.info("Disconnecting bot...")
                asyncio.run(bot.bot.disconnect())
            logger.info("Bot shutdown complete")