# userbot/message_formatter.py
from telethon.types import (
    MessageEntityBold, MessageEntityItalic, MessageEntityCode,
    MessageEntityStrike, MessageEntityUnderline, MessageEntityPre,
    MessageEntityTextUrl, MessageEntityMention, MessageEntityHashtag,
    MessageEntityUrl, MessageEntitySpoiler, MessageEntityCustomEmoji,
    MessageEntityBlockquote, MessageEntityCashtag, MessageEntityPhone,
    MessageEntityEmail, MessageEntityBotCommand
)
import emoji
import re
from typing import List, Dict, Union, Optional

class MessageFormatter:
    """Handle message formatting including text styles and emojis"""
    
    # Class constant for text styles
    TEXT_STYLES = {
        'bold': '**{}**',
        'italic': '__{}__',
        'code': '`{}`',
        'strike': '~~{}~~',
        'underline': '--{}--',
        'spoiler': '||{}||',
        'quote': '> {}',
        'blockquote': '```{}```',
        'pre': '```{}```'
    }
    
    # Class constant for fonts
    FONTS = {
        'serif': {...},  # Sama seperti sebelumnya
        'bold_serif': {...},
        'cursive': {...},
        'gothic': {...},
        'monospace': {...}
    }

    @staticmethod
    def apply_font(text: str, font_style: str) -> str:
        """Apply special font style to text"""
        if font_style not in MessageFormatter.FONTS:
            return text
            
        result = ""
        for char in text.lower():
            if char in MessageFormatter.FONTS[font_style]:
                result += MessageFormatter.FONTS[font_style][char]
            else:
                result += char
        return result

    @staticmethod
    def apply_style(text: str, style_type: str) -> str:
        """Apply text style (bold, italic, etc)"""
        if style_type in MessageFormatter.TEXT_STYLES:
            return MessageFormatter.TEXT_STYLES[style_type].format(text)
        return text

    @staticmethod
    def parse_entities(text: str, entities: List[Dict]) -> str:
        """Parse and apply formatting from entities"""
        if not entities:
            return text
            
        sorted_entities = sorted(entities, key=lambda x: x["offset"], reverse=True)
        formatted_text = text
        
        for entity in sorted_entities:
            start = entity["offset"]
            length = entity["length"]
            end = start + length
            
            chunk = formatted_text[start:end]
            entity_type = entity["type"].lower()
            
            if entity_type == "messageentitybold":
                styled = f"**{chunk}**"
            elif entity_type == "messageentityitalic":
                styled = f"__{chunk}__"
            elif entity_type == "messageentitycode":
                styled = f"`{chunk}`"
            elif entity_type == "messageentitystrike":
                styled = f"~~{chunk}~~"
            elif entity_type == "messageentityunderline":
                styled = f"--{chunk}--"
            elif entity_type == "messageentitypre":
                styled = f"```{chunk}```"
            elif entity_type == "messageentitytexturl":
                styled = f"[{chunk}]({entity.get('url', '')})"
            elif entity_type == "messageentityspoiler":
                styled = f"||{chunk}||"
            elif entity_type == "messageentityblockquote":
                styled = f"> {chunk}"
            elif entity_type == "messageentitycustomemoji":
                # Preserve custom emoji (including premium ones)
                styled = chunk
            else:
                styled = chunk
                
            formatted_text = formatted_text[:start] + styled + formatted_text[end:]
            
        return formatted_text

    @staticmethod
    def create_entities(text: str) -> List[Dict]:
        """Create entities from formatted text"""
        entities = []
        offset = 0
        
        patterns = {
            'bold': (r'\*\*(.*?)\*\*', 'messageentitybold', 4),
            'italic': (r'__(.*?)__', 'messageentityitalic', 4),
            'code': (r'`(.*?)`', 'messageentitycode', 2),
            'strike': (r'~~(.*?)~~', 'messageentitystrike', 4),
            'underline': (r'--(.*?)--', 'messageentityunderline', 4),
            'spoiler': (r'\|\|(.*?)\|\|', 'messageentityspoiler', 4),
            'pre': (r'```(.*?)```', 'messageentitypre', 6),
            'url': (r'https?://\S+', 'messageentityurl', 0),
            'mention': (r'@\w+', 'messageentitymention', 0),
            'hashtag': (r'#\w+', 'messageentityhashtag', 0),
            'cashtag': (r'\$\w+', 'messageentitycashtag', 0),
            'email': (r'\S+@\S+\.\S+', 'messageentityemail', 0),
            'phone': (r'\+\d+', 'messageentityphone', 0),
            'bot_command': (r'/\w+', 'messageentitybotcommand', 0)
        }
        
        for pattern, entity_type, marker_length in patterns.values():
            for match in re.finditer(pattern, text):
                start, end = match.span()
                if marker_length:
                    start = start + marker_length // 2
                    end = end - marker_length // 2
                entities.append({
                    "type": entity_type,
                    "offset": start - offset,
                    "length": end - start
                })
        
        return sorted(entities, key=lambda x: x['offset'])

    @staticmethod
    def clean_formatted_text(text: str) -> str:
        """Remove formatting markers while preserving emojis"""
        for pattern in [
            r'\*\*(.*?)\*\*',  # Bold
            r'__(.*?)__',      # Italic
            r'`(.*?)`',        # Code
            r'~~(.*?)~~',      # Strike
            r'--(.*?)--',      # Underline
            r'\|\|(.*?)\|\|',  # Spoiler
            r'```(.*?)```',    # Pre/Blockquote
        ]:
            text = re.sub(pattern, r'\1', text)
        return text

    @staticmethod
    def format_caption(caption: str, watermark: Optional[str] = None) -> str:
        """Format caption with optional watermark"""
        if not caption and not watermark:
            return ""
        
        formatted_caption = caption or ""
        if watermark:
            if formatted_caption:
                formatted_caption += f"\n\n{watermark}"
            else:
                formatted_caption = watermark
        
        return formatted_caption

    @classmethod
    def format_message(cls, message: Dict, watermark: Optional[str] = None) -> Dict:
        """Format complete message with all supported formats"""
        formatted = {
            "text": message.get("text", ""),
            "entities": message.get("entities", []),
            "media": message.get("media"),
            "custom_emojis": message.get("custom_emojis", [])
        }
        
        if watermark and formatted["text"]:
            formatted["text"] = cls.format_caption(formatted["text"], watermark)
            if formatted["entities"]:
                watermark_length = len(f"\n\n{watermark}")
                for entity in formatted["entities"]:
                    if entity["offset"] > len(formatted["text"]) - watermark_length:
                        entity["offset"] += watermark_length
        
        return formatted

    @staticmethod
    def convert_to_telethon_entities(entities: List[Dict]) -> List:
        """Convert entity dictionaries to Telethon entity objects"""
        entity_map = {
            "messageentitybold": MessageEntityBold,
            "messageentityitalic": MessageEntityItalic,
            "messageentitycode": MessageEntityCode,
            "messageentitystrike": MessageEntityStrike,
            "messageentityunderline": MessageEntityUnderline,
            "messageentitypre": MessageEntityPre,
            "messageentitytexturl": MessageEntityTextUrl,
            "messageentitymention": MessageEntityMention,
            "messageentityhashtag": MessageEntityHashtag,
            "messageentityurl": MessageEntityUrl,
            "messageentityspoiler": MessageEntitySpoiler,
            "messageentitycustomemoji": MessageEntityCustomEmoji,
            "messageentityblockquote": MessageEntityBlockquote,
            "messageentitycashtag": MessageEntityCashtag,
            "messageentityphone": MessageEntityPhone,
            "messageentityemail": MessageEntityEmail,
            "messageentitybotcommand": MessageEntityBotCommand
        }
        
        telethon_entities = []
        for entity in entities:
            entity_type = entity["type"].lower()
            if entity_type in entity_map:
                EntityClass = entity_map[entity_type]
                entity_kwargs = {
                    "offset": entity["offset"],
                    "length": entity["length"]
                }
                
                # Handle special entity attributes
                if entity_type == "messageentitytexturl":
                    entity_kwargs["url"] = entity.get("url", "")
                elif entity_type == "messageentitypre":
                    entity_kwargs["language"] = entity.get("language", "")
                elif entity_type == "messageentitycustomemoji":
                    entity_kwargs["document_id"] = entity.get("document_id")
                
                telethon_entities.append(EntityClass(**entity_kwargs))
        
        return telethon_entities