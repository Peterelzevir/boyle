# handlers/admin_handlers.py

from telethon import events, Button
from database.database import Database
from config import Config
from typing import Dict, List
import asyncio

class AdminHandlers:
    def __init__(self, bot, db: Database):
        self.bot = bot
        self.db = db
        self.admin_states = {}

    async def admin_panel_handler(self, event):
        if event.sender_id != Config.ADMIN_ID:
            await event.answer("⛔ Access denied!")
            return

        buttons = [
            [
                Button.inline("👥 Add Admin", "add_admin"),
                Button.inline("💎 Add Premium", "add_premium")
            ],
            [
                Button.inline("📢 Broadcast", "broadcast"),
                Button.inline("📊 User List", "user_list")
            ],
            [
                Button.inline("🗑️ Delete Userbot", "delete_userbot"),
                Button.inline("📱 Create Userbot", "admin_create_userbot")
            ],
            [Button.inline("🔙 Back", "start")]
        ]

        await event.edit(
            "👮‍♂️ Admin Panel\n\n"
            "Select an option:",
            buttons=buttons
        )

    async def add_admin_handler(self, event):
        if event.sender_id != Config.ADMIN_ID:
            await event.answer("⛔ Access denied!")
            return

        await event.edit(
            "👤 Kirim User ID yang ingin dijadikan admin:",
            buttons=[[Button.inline("🔙 Back", "admin_panel")]]
        )
        self.admin_states[event.sender_id] = "waiting_admin_id"

    async def handle_admin_id(self, event):
        if event.sender_id != Config.ADMIN_ID:
            return

        try:
            user_id = int(event.text.strip())
            await self.db.add_user(user_id, access_type="admin")
            
            await event.reply(
                f"✅ User ID: {user_id} berhasil dijadikan admin!",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
            
        except ValueError:
            await event.reply(
                "❌ User ID tidak valid! Mohon kirim angka saja.",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

    async def add_premium_handler(self, event):
        if event.sender_id != Config.ADMIN_ID:
            await event.answer("⛔ Access denied!")
            return

        buttons = [
            [
                Button.inline("💎 Premium", "premium_normal"),
                Button.inline("💎+ Premium Plus", "premium_plus")
            ],
            [Button.inline("🔙 Back", "admin_panel")]
        ]

        await event.edit(
            "💎 Pilih jenis premium:",
            buttons=buttons
        )

    async def handle_premium_type(self, event):
        if event.sender_id != Config.ADMIN_ID:
            return

        premium_type = event.data.decode().split("_")[-1]
        self.admin_states[event.sender_id] = {
            "state": "waiting_premium_user",
            "premium_type": premium_type
        }

        await event.edit(
            "👤 Kirim User ID yang ingin dijadikan premium:",
            buttons=[[Button.inline("🔙 Back", "admin_panel")]]
        )

    async def handle_premium_user(self, event):
        if event.sender_id != Config.ADMIN_ID:
            return

        try:
            user_id = int(event.text.strip())
            state_data = self.admin_states[event.sender_id]
            premium_type = state_data["premium_type"]

            # Ask for duration
            self.admin_states[event.sender_id] = {
                "state": "waiting_premium_duration",
                "user_id": user_id,
                "premium_type": premium_type
            }

            await event.reply(
                "⏱️ Masukkan durasi premium dalam hari:",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

        except ValueError:
            await event.reply(
                "❌ User ID tidak valid! Mohon kirim angka saja.",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

    async def handle_premium_duration(self, event):
        if event.sender_id != Config.ADMIN_ID:
            return

        try:
            duration = int(event.text.strip())
            state_data = self.admin_states[event.sender_id]
            user_id = state_data["user_id"]
            premium_type = state_data["premium_type"]

            access_type = "premium_plus" if premium_type == "plus" else "premium"
            await self.db.add_user(user_id, access_type=access_type, duration=duration)

            await event.reply(
                f"✅ Berhasil menambahkan user premium!\n\n"
                f"User ID: {user_id}\n"
                f"Tipe: {access_type}\n"
                f"Durasi: {duration} hari",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

            # Notify user
            try:
                await self.bot.send_message(
                    user_id,
                    f"🎉 Selamat! Akun Anda telah diupgrade ke {access_type}!\n"
                    f"Durasi: {duration} hari"
                )
            except:
                pass

            del self.admin_states[event.sender_id]

        except ValueError:
            await event.reply(
                "❌ Durasi tidak valid! Mohon kirim angka saja.",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

    async def broadcast_handler(self, event):
        if event.sender_id != Config.ADMIN_ID:
            await event.answer("⛔ Access denied!")
            return

        await event.edit(
            "📢 Kirim pesan yang ingin di-broadcast ke semua user:\n"
            "• Support semua format teks\n"
            "• Support media dengan caption",
            buttons=[[Button.inline("🔙 Back", "admin_panel")]]
        )
        self.admin_states[event.sender_id] = "waiting_broadcast"

    async def handle_broadcast(self, event):
        if event.sender_id != Config.ADMIN_ID:
            return

        message = event.message
        users = await self.db.get_all_users()

        success = 0
        failed = 0

        progress_msg = await event.reply("📤 Memulai broadcast...")

        for user in users:
            try:
                if message.media:
                    await self.bot.send_file(
                        user["user_id"],
                        file=message.media,
                        caption=message.text if message.text else None
                    )
                else:
                    await self.bot.send_message(
                        user["user_id"],
                        message.text
                    )
                success += 1
                
                # Update progress setiap 10 user
                if success % 10 == 0:
                    await progress_msg.edit(
                        f"📤 Broadcasting...\n"
                        f"✅ Berhasil: {success}\n"
                        f"❌ Gagal: {failed}"
                    )
                    
            except:
                failed += 1

        await progress_msg.edit(
            f"📢 Broadcast selesai!\n\n"
            f"✅ Berhasil: {success}\n"
            f"❌ Gagal: {failed}",
            buttons=[[Button.inline("🔙 Back", "admin_panel")]]
        )

    async def user_list_handler(self, event):
        if event.sender_id != Config.ADMIN_ID:
            await event.answer("⛔ Access denied!")
            return

        users = await self.db.get_all_users()
        
        text = "👥 Daftar User:\n\n"
        
        # Group users by access type
        user_groups = {
            "admin": [],
            "premium_plus": [],
            "premium": [],
            "regular": []
        }

        for user in users:
            user_groups[user["access_type"]].append(user)

        # Format text
        for access_type, users in user_groups.items():
            if users:
                text += f"\n{access_type.upper()}:\n"
                for user in users:
                    text += f"• ID: {user['user_id']}"
                    if user.get("expire_at"):
                        text += f" (Expires: {user['expire_at'].strftime('%Y-%m-%d')})"
                    text += "\n"

        # Split text if too long
        if len(text) > 4096:
            chunks = [text[i:i+4096] for i in range(0, len(text), 4096)]
            for i, chunk in enumerate(chunks):
                if i == 0:
                    await event.edit(
                        chunk,
                        buttons=[[Button.inline("🔙 Back", "admin_panel")]]
                    )
                else:
                    await event.respond(chunk)
        else:
            await event.edit(
                text,
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )

    async def delete_userbot_handler(self, event):
        if event.sender_id != Config.ADMIN_ID:
            await event.answer("⛔ Access denied!")
            return

        userbots = await self.db.get_all_userbots()
        
        if not userbots:
            await event.edit(
                "❌ Tidak ada userbot yang aktif.",
                buttons=[[Button.inline("🔙 Back", "admin_panel")]]
            )
            return

        buttons = []
        for userbot in userbots:
            user = await self.db.get_user(userbot["user_id"])
            button_text = f"🗑️ User ID: {userbot['user_id']}"
            if user:
                button_text += f" ({user['access_type']})"
            buttons.append([Button.inline(button_text, f"confirm_delete_{userbot['user_id']}")])

        buttons.append([Button.inline("🔙 Back", "admin_panel")])

        await event.edit(
            "🗑️ Pilih userbot yang ingin dihapus:",
            buttons=buttons
        )

    async def confirm_delete_userbot(self, event):
        if event.sender_id != Config.ADMIN_ID:
            await event.answer("⛔ Access denied!")
            return

        user_id = int(event.data.decode().split("_")[-1])
        
        await self.db.delete_userbot(user_id)
        
        # Stop userbot if running
        if user_id in self.bot.active_userbots:
            await self.bot.active_userbots[user_id].stop()
            del self.bot.active_userbots[user_id]

        await event.edit(
            f"✅ Userbot untuk User ID: {user_id} berhasil dihapus!",
            buttons=[[Button.inline("🔙 Back", "admin_panel")]]
        )

    async def admin_create_userbot(self, event):
        """Handle userbot creation"""
        user = await self.db.get_user(event.sender_id)
        if not user or user.access_type not in ["admin", "premium", "premium_plus"]:
            await event.edit(
                Config.format_error("not_authorized"),
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            return

        self.otp_attempts[event.sender_id] = 0
        
        await event.edit(
            "📱 Kirim nomor telepon dalam format internasional\n"
            "Contoh: +6281234567890",
            buttons=[[Button.inline("🔙 Back", "start")]]
        )
        self.user_states[event.sender_id] = "waiting_phone"

    async def handle_phone_number(self, event):
        """Handle phone number input"""
        if event.sender_id not in self.user_states:
            return
            
        phone = event.text.strip()
        if not re.match(r'^\+\d{10,15}$', phone):
            await event.reply(
                Config.format_error("invalid_phone"),
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            return

        try:
            client = TelegramClient(StringSession(), Config.API_ID, Config.API_HASH)
            await client.connect()
            
            code_request = await client.send_code_request(phone)
            self.user_states[event.sender_id] = {
                "state": "waiting_code",
                "phone": phone,
                "client": client,
                "code_request": code_request
            }
            
            await event.reply(
                "📤 Kode telah dikirim! Masukkan kode dengan spasi.\n"
                "Contoh: 1 2 3 4 5",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
        except PhoneNumberBannedError:
            await event.reply(
                "❌ Nomor telepon ini telah dibanned oleh Telegram!",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
        except FloodWaitError as e:
            await event.reply(
                f"❌ Terlalu banyak permintaan! Tunggu {e.seconds} detik.",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
        except Exception as e:
            await event.reply(
                f"❌ Terjadi kesalahan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )

    async def handle_code(self, event):
        """Handle OTP code input"""
        if event.sender_id not in self.user_states:
            await event.reply("❌ Sesi telah berakhir. Silakan mulai dari awal.")
            return

        code = "".join(event.text.split())
        if not code.isdigit():
            self.otp_attempts[event.sender_id] = self.otp_attempts.get(event.sender_id, 0) + 1

            if self.otp_attempts[event.sender_id] >= Config.MAX_OTP_ATTEMPTS:
                await event.reply(
                    Config.format_error("max_otp_attempts"),
                    buttons=[[Button.inline("🔙 Back", "start")]]
                )
                return

            await event.reply(Config.format_error("invalid_otp"))
            return

        try:
            state_data = self.user_states[event.sender_id]
            client = state_data["client"]
            
            await client.sign_in(
                state_data["phone"],
                code,
                phone_code_hash=state_data["code_request"].phone_code_hash
            )
            
            session_string = StringSession.save(client.session)
            await self.db.add_userbot(event.sender_id, session_string)
            
            await event.reply(
                "✅ Userbot berhasil dibuat!\n\n"
                "⚠️ PENTING: Simpan session string ini!\n"
                f"`{session_string}`\n\n"
                "Gunakan /start untuk mengakses pengaturan userbot.",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            
            del self.user_states[event.sender_id]
            if event.sender_id in self.otp_attempts:
                del self.otp_attempts[event.sender_id]
                
        except PhoneCodeInvalidError:
            self.otp_attempts[event.sender_id] = self.otp_attempts.get(event.sender_id, 0) + 1
            
            if self.otp_attempts[event.sender_id] >= Config.MAX_OTP_ATTEMPTS:
                await event.reply(
                    Config.format_error("max_otp_attempts"),
                    buttons=[[Button.inline("🔙 Back", "start")]]
                )
                return
                
            await event.reply("❌ Kode OTP salah! Silakan coba lagi.")
            
        except SessionPasswordNeededError:
            self.user_states[event.sender_id]["state"] = "waiting_2fa"
            await event.reply(
                "🔐 Akun ini menggunakan Two-Factor Authentication.\n"
                "Silakan masukkan password 2FA Anda:",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            
        except Exception as e:
            await event.reply(
                f"❌ Terjadi kesalahan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )

    async def handle_2fa(self, event):
        """Handle 2FA password input"""
        if event.sender_id not in self.user_states:
            await event.reply("❌ Sesi telah berakhir. Silakan mulai dari awal.")
            return

        try:
            state_data = self.user_states[event.sender_id]
            client = state_data["client"]
            password = event.text.strip()

            await client.sign_in(password=password)
            session_string = StringSession.save(client.session)
            await self.db.add_userbot(event.sender_id, session_string)

            await event.reply(
                "✅ Userbot berhasil dibuat!\n\n"
                "⚠️ PENTING: Simpan session string ini!\n"
                f"`{session_string}`\n\n"
                "Gunakan /start untuk mengakses pengaturan userbot.",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )

            del self.user_states[event.sender_id]

        except PasswordHashInvalidError:
            await event.reply("❌ Password 2FA salah! Silakan coba lagi.")
        except Exception as e:
            await event.reply(
                f"❌ Terjadi kesalahan: {str(e)}",
                buttons=[[Button.inline("🔙 Back", "start")]]
            )

    async def settings_handler(self, event):
        """Handle settings menu"""
        userbot = await self.db.get_userbot(event.sender_id)
        if not userbot:
            await event.edit(
                Config.format_error("no_userbot"),
                buttons=[[Button.inline("🔙 Back", "start")]]
            )
            return

        buttons = [
            [Button.inline("📊 Status", "status"), 
             Button.inline("📝 Check Lists", "check_lists")],
            [Button.inline("➕ Add List", "add_list"),
             Button.inline("📨 Send to RC", "send_rc")],
            [Button.inline("👥 Add Groups", "add_groups"),
             Button.inline("📋 List Groups", "list_groups")],
            [Button.inline("🗑️ Delete Group", "delete_group"),
             Button.inline("📥 Join Group", "join_group")],
            [Button.inline("⏱️ Set Delay", "set_delay"),
             Button.inline("❌ Delete List", "delete_list")],
            [Button.inline("🔙 Back", "start")]
        ]
        
        await event.edit(
            f"⚙️ Pengaturan Userbot\n\n"
            f"Status: {'🟢 Active' if userbot.status == 'active' else '🔴 Inactive'}\n\n"
            "Pilih opsi di bawah:",
            buttons=buttons
        )

    async def status_handler(self, event):
        """Handle status change"""
        userbot = await self.db.get_userbot(event.sender_id)
        if not userbot:
            await event.edit(
                Config.format_error("no_userbot"),
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        current_status = userbot.status
        new_status = "active" if current_status == "inactive" else "inactive"
        
        buttons = [
            [Button.inline(f"✅ Ya, ubah ke {new_status}", f"confirm_status_{new_status}"),
             Button.inline("❌ Tidak", "settings_userbot")]
        ]
        
        await event.edit(
            f"📊 Status Userbot\n\n"
            f"Status saat ini: {current_status}\n"
            f"Ubah ke: {new_status}\n\n"
            f"{'⚠️ Bot akan mulai mengirim pesan' if new_status == 'active' else '⚠️ Bot akan berhenti mengirim pesan'}",
            buttons=buttons
        )

    async def confirm_status_handler(self, event):
        """Handle status confirmation"""
        status = event.data.decode().split("_")[-1]
        user_id = event.sender_id
        
        await self.db.update_userbot_status(user_id, status)
        
        if status == "active":
            userbot_data = await self.db.get_userbot(user_id)
            user_data = await self.db.get_user(user_id)
            
            userbot = UserBot(
                userbot_data.session_string,
                Config.API_ID,
                Config.API_HASH,
                user_data.access_type
            )
            
            await userbot.start()
            self.active_userbots[user_id] = userbot
            
            asyncio.create_task(self.handle_broadcasting(user_id))
            
            await event.edit(
                "✅ Status berhasil diubah ke active!\n"
                "Bot akan mulai mengirim pesan...",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
        else:
            if user_id in self.active_userbots:
                await self.active_userbots[user_id].stop()
                del self.active_userbots[user_id]
            
            await event.edit(
                "✅ Status berhasil diubah ke inactive!\n"
                "Bot telah berhenti mengirim pesan.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

    async def check_lists_handler(self, event):
        """Handle list check"""
        messages = await self.db.get_messages(event.sender_id)
        
        if not messages:
            await event.edit(
                "📝 Belum ada pesan dalam list.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return
            
        text = "📝 List Pesan:\n\n"
        for i, msg in enumerate(messages, 1):
            text += f"{i}. "
            if msg.media:
                text += "[Media] "
            text += f"{msg.text[:50]}...\nDelay: {msg.delay}s\n\n"
            
        await event.edit(text, buttons=[[Button.inline("🔙 Back", "settings_userbot")]])

    async def add_list_handler(self, event):
        """Handle list addition"""
        await event.edit(
            "📝 Kirim pesan yang ingin ditambahkan ke list.\n\n"
            "• Support semua format teks\n"
            "• Support emoji premium\n"
            "• Support foto/video/gif dengan caption",
            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
        )
        self.user_states[event.sender_id]
        
    async def handle_message_input(self, event):
        """Handle message input for list"""
        if event.sender_id not in self.user_states:
            return

        user_id = event.sender_id
        message = event.message

        # Format message with text and entities
        formatted_message = {
            "text": message.text or message.caption or "",
            "entities": [e.to_dict() for e in (message.entities or [])],
            "media": None
        }

        # Handle media
        if message.media:
            media_bytes = await message.download_media(bytes)
            formatted_message["media"] = {
                "type": self._get_media_type(message.media),
                "file": media_bytes
            }

        # Move to delay input state
        self.user_states[user_id] = {
            "state": "waiting_delay",
            "message": formatted_message
        }

        await event.reply(
            "⏱️ Berapa detik delay untuk pesan ini? (1-3600)",
            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
        )

    async def handle_delay_input(self, event):
        """Handle delay input"""
        if event.sender_id not in self.user_states:
            return

        try:
            delay = int(event.text)
            if not 1 <= delay <= 3600:
                raise ValueError

            state_data = self.user_states[event.sender_id]
            message = state_data["message"]
            message["delay"] = delay

            await self.db.add_message(event.sender_id, message)

            await event.reply(
                "✅ Pesan berhasil ditambahkan ke list!",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

            del self.user_states[event.sender_id]

        except ValueError:
            await event.reply(
                "❌ Delay tidak valid! Masukkan angka antara 1-3600 detik.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

    async def delete_list_handler(self, event):
        """Handle list deletion"""
        messages = await self.db.get_messages(event.sender_id)

        if not messages:
            await event.edit(
                "📝 Tidak ada pesan yang bisa dihapus.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        buttons = []
        for message in messages:
            text = f"[Media] " if message.media else ""
            text += message.text[:30] + "..."
            buttons.append([Button.inline(text, f"delete_msg_{message.id}")])

        buttons.append([Button.inline("🔙 Back", "settings_userbot")])

        await event.edit(
            "🗑️ Pilih pesan yang ingin dihapus:",
            buttons=buttons
        )

    async def confirm_delete_message(self, event):
        """Handle message deletion confirmation"""
        message_id = int(event.data.decode().split("_")[-1])
        await self.db.delete_message(event.sender_id, message_id)
        
        await event.edit(
            "✅ Pesan berhasil dihapus!",
            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
        )

    async def add_groups_handler(self, event):
        """Handle group addition"""
        await event.edit(
            "👥 Forward pesan dari grup yang ingin ditambahkan\n"
            "atau kirim username/link grupnya.",
            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
        )
        self.user_states[event.sender_id] = "waiting_group"

    async def handle_group_input(self, event):
        """Handle group input"""
        if event.sender_id not in self.user_states:
            return

        try:
            if event.message.forward:
                chat_id = event.message.forward.chat_id
                chat = await event.client.get_entity(chat_id)
            else:
                text = event.text.strip()
                if text.startswith("@"):
                    username = text[1:]
                elif text.startswith("https://t.me/"):
                    username = text.split("/")[-1]
                else:
                    raise ValueError
                    
                chat = await event.client.get_entity(username)

            # Add to database
            await self.db.add_group(event.sender_id, {
                "id": chat.id,
                "title": chat.title,
                "username": chat.username
            })

            await event.reply(
                f"✅ Grup {chat.title} berhasil ditambahkan!",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

            del self.user_states[event.sender_id]

        except Exception as e:
            await event.reply(
                "❌ Gagal menambahkan grup. Pastikan:\n"
                "• Bot adalah member grup\n"
                "• Format username/link benar\n"
                "• Grup masih aktif",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

    async def list_groups_handler(self, event):
        """Handle group list display"""
        groups = await self.db.get_groups(event.sender_id)

        if not groups:
            await event.edit(
                "👥 Belum ada grup yang ditambahkan.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        text = "📋 List Grup:\n\n"
        for i, group in enumerate(groups, 1):
            text += f"{i}. {group.title}"
            if group.username:
                text += f" (@{group.username})"
            text += f"\nID: {group.group_id}\n\n"

        await event.edit(
            text,
            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
        )

    async def delete_group_handler(self, event):
        """Handle group deletion"""
        groups = await self.db.get_groups(event.sender_id)

        if not groups:
            await event.edit(
                "👥 Tidak ada grup yang bisa dihapus.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        buttons = []
        for group in groups:
            text = group.title
            if group.username:
                text += f" (@{group.username})"
            buttons.append([Button.inline(text, f"delete_group_{group.group_id}")])

        buttons.append([Button.inline("🔙 Back", "settings_userbot")])

        await event.edit(
            "🗑️ Pilih grup yang ingin dihapus:",
            buttons=buttons
        )

    async def confirm_delete_group(self, event):
        """Handle group deletion confirmation"""
        group_id = int(event.data.decode().split("_")[-1])
        await self.db.remove_group(event.sender_id, group_id)

        await event.edit(
            "✅ Grup berhasil dihapus!",
            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
        )

    async def set_delay_handler(self, event):
        """Handle delay setting"""
        messages = await self.db.get_messages(event.sender_id)

        if not messages:
            await event.edit(
                "📝 Tidak ada pesan yang bisa diatur delaynya.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )
            return

        buttons = []
        for message in messages:
            text = f"[Media] " if message.media else ""
            text += f"{message.text[:30]}... ({message.delay}s)"
            buttons.append([Button.inline(text, f"set_delay_{message.id}")])

        buttons.append([Button.inline("🔙 Back", "settings_userbot")])

        await event.edit(
            "⏱️ Pilih pesan yang ingin diubah delaynya:",
            buttons=buttons
        )

    async def handle_new_delay(self, event):
        """Handle new delay input"""
        if event.sender_id not in self.user_states:
            return

        try:
            delay = int(event.text)
            if not 1 <= delay <= 3600:
                raise ValueError

            message_id = self.user_states[event.sender_id]["message_id"]
            await self.db.update_message_delay(event.sender_id, message_id, delay)

            await event.reply(
                "✅ Delay berhasil diubah!",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

            del self.user_states[event.sender_id]

        except ValueError:
            await event.reply(
                "❌ Delay tidak valid! Masukkan angka antara 1-3600 detik.",
                buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
            )

    async def send_rc_handler(self, event):
        """Handle RC message sending"""
        await event.edit(
            "📨 Kirim pesan yang ingin disebarkan ke recent chats:\n\n"
            "• Support semua format teks\n"
            "• Support emoji premium\n"
            "• Support foto/video/gif dengan caption",
            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
        )
        self.user_states[event.sender_id] = "waiting_rc_message"

    async def handle_rc_message(self, event):
        """Handle RC message input"""
        if event.sender_id not in self.user_states:
            return

        userbot_data = await self.db.get_userbot(event.sender_id)
        user_data = await self.db.get_user(event.sender_id)

        if not userbot_data:
            await event.reply("❌ Userbot tidak ditemukan!")
            return

        userbot = UserBot(
            userbot_data.session_string,
            Config.API_ID,
            Config.API_HASH,
            user_data.access_type
        )

        await userbot.start()

        message = event.message
        formatted_message = {
            "text": message.text or message.caption or "",
            "entities": [e.to_dict() for e in (message.entities or [])],
            "media": None
        }

        if message.media:
            media_bytes = await message.download_media(bytes)
            formatted_message["media"] = {
                "type": self._get_media_type(message.media),
                "file": media_bytes
            }

        result = await userbot.send_to_recent_chats(formatted_message)

        await userbot.stop()

        report = (
            "📊 Hasil Pengiriman RC:\n\n"
            f"✅ Berhasil: {result['success_count']}\n"
            f"❌ Gagal: {result['fail_count']}\n\n"
        )

        if result['failed_chats']:
            report += "Chat yang gagal:\n"
            for chat in result['failed_chats']:
                report += f"• {chat}\n"

        await event.reply(
            report,
            buttons=[[Button.inline("🔙 Back", "settings_userbot")]]
        )

        del self.user_states[event.sender_id]

    def _get_media_type(self, media):
        """Helper to determine media type"""
        if isinstance(media, MessageMediaPhoto):
            return "photo"
        elif isinstance(media, MessageMediaDocument):
            if media.document.mime_type.startswith("video"):
                return "video"
            elif media.document.mime_type == "image/gif":
                return "gif"
        return None

    async def handle_broadcasting(self, user_id):
        """Handle message broadcasting"""
        if user_id not in self.active_userbots:
            return

        userbot = self.active_userbots[user_id]
        messages = await self.db.get_messages(user_id)
        groups = await self.db.get_groups(user_id)

        if not messages or not groups:
            await self.bot.send_message(
                user_id,
                "❌ Tidak ada pesan atau grup yang ditambahkan!"
            )
            return

        user = await self.db.get_user(user_id)
        watermark = Config.WATERMARK if user.access_type == "premium" else None

        while user_id in self.active_userbots:
            for message in messages:
                if user_id not in self.active_userbots:
                    break

                for group in groups:
                    if user_id not in self.active_userbots:
                        break

                    try:
                        await userbot.send_message_to_group(
                            group.group_id,
                            message,
                            watermark=watermark
                        )

                        await self.bot.send_message(
                            user_id,
                            f"✅ Pesan berhasil dikirim ke {group.title}"
                        )
                    except Exception as e:
                        await self.bot.send_message(
                            user_id,
                            f"❌ Gagal mengirim ke {group.title}: {str(e)}"
                        )

                    await asyncio.sleep(message.delay)