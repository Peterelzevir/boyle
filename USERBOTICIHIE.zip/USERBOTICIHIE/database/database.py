# database/database.py
import sqlite3
import json
from datetime import datetime, timedelta
import aiosqlite
import asyncio
from typing import List, Dict, Optional
from .models import User, Message, Group, Userbot, AllowedGroup

class Database:
    def __init__(self, db_name: str = "userbot.db"):
        self.db_name = db_name
        self._create_tables()
    
    def _create_tables(self):
        """Create necessary tables if they don't exist"""
        with sqlite3.connect(self.db_name) as conn:
            c = conn.cursor()
            
            # Users table
            c.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    access_type TEXT DEFAULT 'regular',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expire_at TIMESTAMP,
                    phone TEXT
                )
            ''')
            
            # Userbots table
            c.execute('''
                CREATE TABLE IF NOT EXISTS userbots (
                    user_id INTEGER PRIMARY KEY,
                    session_string TEXT,
                    status TEXT DEFAULT 'inactive',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
            ''')
            
            # Messages table
            c.execute('''
                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    text TEXT,
                    media BLOB,
                    delay INTEGER DEFAULT 60,
                    entities TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
            ''')
            
            # Groups table (all joined groups)
            c.execute('''
                CREATE TABLE IF NOT EXISTS groups (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    group_id INTEGER,
                    title TEXT,
                    username TEXT,
                    join_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
            ''')

            # Allowed Groups table (groups allowed for broadcasting)
            c.execute('''
                CREATE TABLE IF NOT EXISTS allowed_groups (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    group_id INTEGER,
                    title TEXT,
                    username TEXT,
                    added_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
            ''')
            
            conn.commit()

    # User Methods
    async def add_user(self, user_id: int, access_type: str = "regular", duration: Optional[int] = None) -> None:
        expire_at = (datetime.now() + timedelta(days=duration)).isoformat() if duration else None
        async with aiosqlite.connect(self.db_name) as db:
            await db.execute(
                'INSERT OR REPLACE INTO users (user_id, access_type, expire_at) VALUES (?, ?, ?)',
                (user_id, access_type, expire_at)
            )
            await db.commit()

    async def get_user(self, user_id: int) -> Optional[User]:
        async with aiosqlite.connect(self.db_name) as db:
            async with db.execute('SELECT * FROM users WHERE user_id = ?', (user_id,)) as cursor:
                row = await cursor.fetchone()
                if row:
                    return User(
                        user_id=row[0],
                        access_type=row[1],
                        created_at=datetime.fromisoformat(row[2]),
                        expire_at=datetime.fromisoformat(row[3]) if row[3] else None,
                        phone=row[4]
                    )
                return None

    async def update_user_access(self, user_id: int, access_type: str, duration: Optional[int] = None) -> None:
        expire_at = (datetime.now() + timedelta(days=duration)).isoformat() if duration else None
        async with aiosqlite.connect(self.db_name) as db:
            await db.execute(
                'UPDATE users SET access_type = ?, expire_at = ? WHERE user_id = ?',
                (access_type, expire_at, user_id)
            )
            await db.commit()

    # Userbot Methods
    async def add_userbot(self, user_id: int, session_string: str) -> None:
        async with aiosqlite.connect(self.db_name) as db:
            await db.execute(
                'INSERT OR REPLACE INTO userbots (user_id, session_string) VALUES (?, ?)',
                (user_id, session_string)
            )
            await db.commit()

    async def get_userbot(self, user_id: int) -> Optional[Userbot]:
        async with aiosqlite.connect(self.db_name) as db:
            # Get userbot basic info
            async with db.execute('SELECT * FROM userbots WHERE user_id = ?', (user_id,)) as cursor:
                row = await cursor.fetchone()
                if not row:
                    return None

            # Get messages
            messages = await self.get_messages(user_id)
            
            # Get all joined groups
            groups = await self.get_groups(user_id)
            
            # Get allowed groups
            allowed_groups = await self.get_allowed_groups(user_id)

            return Userbot(
                user_id=row[0],
                session_string=row[1],
                status=row[2],
                created_at=datetime.fromisoformat(row[3]),
                messages=messages,
                groups=groups,
                allowed_groups=allowed_groups
            )

    async def update_userbot_status(self, user_id: int, status: str) -> None:
        async with aiosqlite.connect(self.db_name) as db:
            await db.execute(
                'UPDATE userbots SET status = ? WHERE user_id = ?',
                (status, user_id)
            )
            await db.commit()

    # Message Methods
    async def add_message(self, user_id: int, message: Dict) -> None:
        media_json = json.dumps(message.get("media")) if message.get("media") else None
        entities_json = json.dumps(message.get("entities", [])) if message.get("entities") else None
        
        async with aiosqlite.connect(self.db_name) as db:
            await db.execute(
                'INSERT INTO messages (user_id, text, media, delay, entities) VALUES (?, ?, ?, ?, ?)',
                (user_id, message.get("text", ""), media_json, message.get("delay", 60), entities_json)
            )
            await db.commit()

    async def get_messages(self, user_id: int) -> List[Message]:
        async with aiosqlite.connect(self.db_name) as db:
            async with db.execute('SELECT * FROM messages WHERE user_id = ?', (user_id,)) as cursor:
                rows = await cursor.fetchall()
                messages = []
                for row in rows:
                    messages.append(Message(
                        id=row[0],
                        text=row[2],
                        media=json.loads(row[3]) if row[3] else None,
                        delay=row[4],
                        entities=json.loads(row[5]) if row[5] else [],
                        created_at=datetime.fromisoformat(row[6])
                    ))
                return messages

    async def delete_message(self, user_id: int, message_id: int) -> None:
        async with aiosqlite.connect(self.db_name) as db:
            await db.execute(
                'DELETE FROM messages WHERE user_id = ? AND id = ?',
                (user_id, message_id)
            )
            await db.commit()

    # Group Methods
    async def add_group(self, user_id: int, group: Dict) -> None:
        """Add a group to joined groups list"""
        async with aiosqlite.connect(self.db_name) as db:
            await db.execute(
                'INSERT INTO groups (user_id, group_id, title, username) VALUES (?, ?, ?, ?)',
                (user_id, group["id"], group["title"], group.get("username"))
            )
            await db.commit()

    async def get_groups(self, user_id: int) -> List[Group]:
        """Get all joined groups"""
        async with aiosqlite.connect(self.db_name) as db:
            async with db.execute('SELECT * FROM groups WHERE user_id = ?', (user_id,)) as cursor:
                rows = await cursor.fetchall()
                return [Group(
                    id=row[0],
                    group_id=row[2],
                    title=row[3],
                    username=row[4],
                    join_date=datetime.fromisoformat(row[5])
                ) for row in rows]

    async def add_allowed_group(self, user_id: int, group: Dict) -> None:
        """Add a group to allowed groups list"""
        async with aiosqlite.connect(self.db_name) as db:
            await db.execute(
                'INSERT INTO allowed_groups (user_id, group_id, title, username) VALUES (?, ?, ?, ?)',
                (user_id, group["id"], group["title"], group.get("username"))
            )
            await db.commit()

    async def get_allowed_groups(self, user_id: int) -> List[AllowedGroup]:
        """Get all allowed groups"""
        async with aiosqlite.connect(self.db_name) as db:
            async with db.execute('SELECT * FROM allowed_groups WHERE user_id = ?', (user_id,)) as cursor:
                rows = await cursor.fetchall()
                return [AllowedGroup(
                    id=row[0],
                    group_id=row[2],
                    title=row[3],
                    username=row[4],
                    added_date=datetime.fromisoformat(row[5])
                ) for row in rows]

    async def remove_allowed_group(self, user_id: int, group_id: int) -> None:
        """Remove a group from allowed groups list"""
        async with aiosqlite.connect(self.db_name) as db:
            await db.execute(
                'DELETE FROM allowed_groups WHERE user_id = ? AND group_id = ?',
                (user_id, group_id)
            )
            await db.commit()

    async def remove_group(self, user_id: int, group_id: int) -> None:
        """Remove a group from joined groups list"""
        async with aiosqlite.connect(self.db_name) as db:
            await db.execute(
                'DELETE FROM groups WHERE user_id = ? AND group_id = ?',
                (user_id, group_id)
            )
            await db.commit()

    # Additional Methods
    async def get_all_users(self) -> List[User]:
        async with aiosqlite.connect(self.db_name) as db:
            async with db.execute('SELECT * FROM users') as cursor:
                rows = await cursor.fetchall()
                return [User(
                    user_id=row[0],
                    access_type=row[1],
                    created_at=datetime.fromisoformat(row[2]),
                    expire_at=datetime.fromisoformat(row[3]) if row[3] else None,
                    phone=row[4]
                ) for row in rows]

    async def delete_userbot(self, user_id: int) -> None:
        async with aiosqlite.connect(self.db_name) as db:
            await db.execute('DELETE FROM userbots WHERE user_id = ?', (user_id,))
            await db.execute('DELETE FROM messages WHERE user_id = ?', (user_id,))
            await db.execute('DELETE FROM groups WHERE user_id = ?', (user_id,))
            await db.execute('DELETE FROM allowed_groups WHERE user_id = ?', (user_id,))
            await db.commit()

    async def check_expired_users(self) -> List[User]:
        """Get list of users whose premium access has expired"""
        current_time = datetime.now()
        async with aiosqlite.connect(self.db_name) as db:
            async with db.execute(
                'SELECT * FROM users WHERE expire_at IS NOT NULL AND expire_at < ?',
                (current_time.isoformat(),)
            ) as cursor:
                rows = await cursor.fetchall()
                return [User(
                    user_id=row[0],
                    access_type=row[1],
                    created_at=datetime.fromisoformat(row[2]),
                    expire_at=datetime.fromisoformat(row[3]) if row[3] else None,
                    phone=row[4]
                ) for row in rows]