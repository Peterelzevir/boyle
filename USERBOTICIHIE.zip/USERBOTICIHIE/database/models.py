# database/models.py
from datetime import datetime
from typing import Optional, List, Dict
from pydantic import BaseModel

class User(BaseModel):
    user_id: int
    access_type: str = "regular"  # regular, premium, premium_plus, admin
    created_at: datetime = datetime.now()
    expire_at: Optional[datetime]
    phone: Optional[str]

class Message(BaseModel):
    id: int
    text: str
    media: Optional[Dict] = None
    delay: int = 60
    entities: Optional[List[Dict]] = []
    created_at: datetime = datetime.now()

class Group(BaseModel):
    id: int
    group_id: int
    title: str
    username: Optional[str]
    is_allowed: bool = False  # Whether group is allowed for broadcasting
    join_date: datetime = datetime.now()

class AllowedGroup(BaseModel):
    id: int
    group_id: int
    title: str
    username: Optional[str]
    added_date: datetime = datetime.now()

class Userbot(BaseModel):
    user_id: int
    session_string: str
    status: str = "inactive"  # inactive, active
    created_at: datetime = datetime.now()
    messages: List[Message] = []
    groups: List[Group] = []
    allowed_groups: List[AllowedGroup] = []