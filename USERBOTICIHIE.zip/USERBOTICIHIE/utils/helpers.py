# utils/helpers.py
import re
from typing import Union, List, Dict
from telethon.types import MessageEntity
import emoji

class TextFormatter:
    @staticmethod
    def is_valid_phone(phone: str) -> bool:
        """Validate phone number format"""
        return bool(re.match(r'^\+\d{10,15}$', phone))
    
    @staticmethod
    def is_valid_otp(otp: str) -> bool:
        """Validate OTP format"""
        return bool(re.match(r'^\d(\s+\d){4}$', otp))
    
    @staticmethod
    def clean_text(text: str) -> str:
        """Remove unnecessary whitespace and format text"""
        return ' '.join(text.split())
    
    @staticmethod
    def extract_username(text: str) -> str:
        """Extract username from text/link"""
        if text.startswith('@'):
            return text[1:]
        elif text.startswith('https://t.me/'):
            return text.split('/')[-1]
        return text

    @staticmethod
    def has_emoji(text: str) -> bool:
        """Check if text contains emoji"""
        return bool(emoji.emoji_count(text))

class MessageHelper:
    @staticmethod
    def format_message(text: str, entities: List[Dict] = None, media: Dict = None) -> Dict:
        """Format message for storage"""
        return {
            "text": text,
            "entities": entities or [],
            "media": media,
            "has_emoji": TextFormatter.has_emoji(text)
        }
    
    @staticmethod
    def parse_entities(message_entities: List[MessageEntity]) -> List[Dict]:
        """Convert message entities to storable format"""
        entities = []
        for entity in message_entities:
            entity_dict = {
                "offset": entity.offset,
                "length": entity.length,
                "type": entity.__class__.__name__
            }
            if hasattr(entity, 'url'):
                entity_dict["url"] = entity.url
            entities.append(entity_dict)
        return entities

    @staticmethod
    def get_media_info(media: Union[bytes, str], mime_type: str = None) -> Dict:
        """Get media information"""
        media_type = None
        if mime_type:
            if mime_type.startswith('image/'):
                media_type = 'photo' if mime_type != 'image/gif' else 'gif'
            elif mime_type.startswith('video/'):
                media_type = 'video'
            elif mime_type == 'application/x-tgsticker':
                media_type = 'sticker'

        return {
            "type": media_type,
            "file": media
        }

class GroupHelper:
    @staticmethod
    def format_group_info(group: Dict) -> str:
        """Format group information for display"""
        text = f"📌 {group['title']}"
        if group.get('username'):
            text += f" (@{group['username']})"
        text += f"\nID: {group['id']}"
        return text

    @staticmethod
    def chunk_groups(groups: List[Dict], chunk_size: int = 5) -> List[List[Dict]]:
        """Split groups into chunks for pagination"""
        return [groups[i:i + chunk_size] for i in range(0, len(groups), chunk_size)]

class UserHelper:
    @staticmethod
    def format_user_info(user: Dict) -> str:
        """Format user information for display"""
        text = f"👤 User ID: {user['user_id']}\n"
        text += f"📱 Phone: {user.get('phone', 'Not set')}\n"
        text += f"💎 Access: {user['access_type'].upper()}\n"
        if user.get('expire_at'):
            text += f"⏱️ Expires: {user['expire_at'].strftime('%Y-%m-%d %H:%M:%S')}"
        return text