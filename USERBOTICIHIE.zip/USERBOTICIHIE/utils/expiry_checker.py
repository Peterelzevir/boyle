# utils/expiry_checker.py
from datetime import datetime
import asyncio
import logging

logger = logging.getLogger(__name__)

class ExpiryChecker:
    def __init__(self, bot, db):
        self.bot = bot
        self.db = db
        self.running = True

    async def start(self):
        """Start the expiry checker loop"""
        while self.running:
            await self.check_expired_users()
            await asyncio.sleep(360)  # Check setiap jam

    async def stop(self):
        """Stop the expiry checker"""
        self.running = False

    async def check_expired_users(self):
        """Check and handle expired users"""
        current_time = datetime.now()
        users = await self.db.get_all_users()

        for user in users:
            if user.get("expire_at") and current_time >= user["expire_at"]:
                user_id = user["user_id"]
                old_access_type = user["access_type"]

                # Delete userbot if exists
                userbot = await self.db.get_userbot(user_id)
                if userbot:
                    # Stop userbot if running
                    if user_id in self.bot.active_userbots:
                        await self.bot.active_userbots[user_id].stop()
                        del self.bot.active_userbots[user_id]

                    # Delete userbot from database
                    await self.db.delete_userbot(user_id)

                # Update user access type to regular
                await self.db.update_user_access(user_id, "regular")

                # Send notification to user
                try:
                    message = (
                        f"⚠️ **Akses Premium Anda Telah Berakhir!**\n\n"
                        f"📱 Status sebelumnya: {old_access_type.upper()}\n"
                        f"📱 Status sekarang: REGULAR\n\n"
                        f"Perubahan yang terjadi:\n"
                        f"• ❌ Userbot telah dihentikan dan dihapus\n"
                        f"• ❌ Session telah dilepas dari akun\n"
                        f"• ❌ Seluruh list pesan telah dihapus\n"
                        f"• ❌ Seluruh list grup telah dihapus\n\n"
                        f"Untuk mengaktifkan kembali akses premium,\n"
                        f"silakan hubungi @hiyaok"
                    )
                    
                    await self.bot.send_message(
                        user_id,
                        message
                    )

                    # Kirim notif ke admin
                    admin_notif = (
                        f"📊 **Premium User Expired!**\n\n"
                        f"👤 User ID: {user_id}\n"
                        f"📱 Status sebelumnya: {old_access_type.upper()}\n"
                        f"⏰ Waktu expire: {user['expire_at'].strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                        f"✅ Tindakan yang dilakukan:\n"
                        f"• Userbot dihentikan & dihapus\n"
                        f"• Status diubah ke REGULAR\n"
                        f"• Notifikasi terkirim ke user"
                    )

                    await self.bot.send_message(
                        Config.ADMIN_ID,
                        admin_notif
                    )

                except Exception as e:
                    logger.error(f"Error sending expiry notification to {user_id}: {str(e)}")

                logger.info(f"User {user_id} premium access has expired and been handled")