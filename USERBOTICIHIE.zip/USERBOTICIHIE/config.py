# config.py
class Config:
    # Telegram API Credentials
    API_ID = "YOUR_API_ID"  # Ganti dengan API ID Anda
    API_HASH = "YOUR_API_HASH"  # Ganti dengan API Hash Anda
    BOT_TOKEN = "YOUR_BOT_TOKEN"  # Ganti dengan Bot Token Anda
    
    # Database Configuration
    DB_NAME = "userbot.db"  # Nama file database SQLite
    
    # Admin Configuration
    ADMIN_ID = 123456789  # Ganti dengan ID Telegram Anda
    
    # Bot Settings
    BOT_USERNAME = "hiyaokuserbot"  # Username bot Anda
    OWNER_USERNAME = "hiyaok"
    WATERMARK = "Userbot By @hiyaok"
    
    # User Settings
    MAX_USERBOTS_PER_USER = 1  # Maksimal jumlah userbot per user
    MAX_OTP_ATTEMPTS = 3       # Maksimal percobaan OTP
    
    # Message Settings
    MIN_DELAY = 1              # Minimal delay antar pesan (detik)
    MAX_DELAY = 3600          # Maksimal delay antar pesan (detik)
    MAX_MESSAGES = 100        # Maksimal jumlah pesan dalam list
    MAX_GROUPS = 100          # Maksimal jumlah grup
    
    # Premium Settings
    PREMIUM_FEATURES = {
        "regular": {
            "can_create_userbot": False,
            "max_groups": 0,
            "max_messages": 0,
            "needs_watermark": True
        },
        "premium": {
            "can_create_userbot": True,
            "max_groups": 50,
            "max_messages": 50,
            "needs_watermark": True
        },
        "premium_plus": {
            "can_create_userbot": True,
            "max_groups": 100,
            "max_messages": 100,
            "needs_watermark": False
        },
        "admin": {
            "can_create_userbot": True,
            "max_groups": -1,  # Unlimited
            "max_messages": -1, # Unlimited
            "needs_watermark": False
        }
    }
    
    # Session Settings
    SESSION_NAME = "userbot"
    
    # Error Messages
    ERROR_MESSAGES = {
        "not_authorized": "❌ Anda tidak memiliki akses untuk menggunakan fitur ini.\n\nHubungi @hiyaok untuk mendapatkan akses premium.",
        "expired": "❌ Akses premium Anda telah berakhir.",
        "invalid_phone": "❌ Nomor telepon tidak valid. Mohon gunakan format yang benar (contoh: +6281234567890)",
        "invalid_otp": "❌ Kode OTP tidak valid. Mohon masukkan 5 digit angka dengan spasi.",
        "max_otp_attempts": "❌ Terlalu banyak percobaan OTP gagal. Silakan mulai dari awal.",
        "group_limit": "❌ Anda telah mencapai batas maksimum grup.",
        "message_limit": "❌ Anda telah mencapai batas maksimum pesan.",
        "invalid_delay": "❌ Delay tidak valid. Mohon masukkan angka antara {min_delay} dan {max_delay} detik.",
        "userbot_exists": "❌ Anda sudah memiliki userbot aktif.",
        "no_userbot": "❌ Anda belum memiliki userbot.",
        "database_error": "❌ Terjadi kesalahan database. Mohon coba lagi nanti.",
        "2fa_needed": "❌ Akun ini menggunakan Two-Factor Authentication.\nMohon masukkan password 2FA Anda.",
        "invalid_2fa": "❌ Password 2FA tidak valid. Silakan coba lagi.",
        "flood_wait": "❌ Terlalu banyak permintaan. Mohon tunggu {wait_time} detik.",
        "user_deactivated": "❌ Akun telah dinonaktifkan.",
        "user_flood": "❌ Terlalu banyak percobaan. Mohon tunggu beberapa saat.",
        "phone_code_invalid": "❌ Kode OTP tidak valid. Silakan coba lagi.",
        "phone_code_expired": "❌ Kode OTP telah kadaluarsa. Silakan mulai dari awal."
    }
    
    # Success Messages
    SUCCESS_MESSAGES = {
        "userbot_created": "✅ Userbot berhasil dibuat!\n\nGunakan tombol 'Settings Userbot' untuk mengelola userbot Anda.",
        "message_added": "✅ Pesan berhasil ditambahkan ke list!",
        "group_added": "✅ Grup berhasil ditambahkan!",
        "group_removed": "✅ Grup berhasil dihapus!",
        "delay_updated": "✅ Delay berhasil diubah!",
        "status_changed": "✅ Status userbot berhasil diubah!",
        "broadcast_complete": "✅ Broadcast selesai!",
        "premium_added": "✅ User premium berhasil ditambahkan!",
        "admin_added": "✅ Admin berhasil ditambahkan!",
        "list_cleared": "✅ List pesan berhasil dihapus!",
        "message_deleted": "✅ Pesan berhasil dihapus!",
        "rc_sent": "✅ Pesan berhasil dikirim ke recent chats!",
        "joined_group": "✅ Berhasil join grup!"
    }
    
    # Help Messages
    HELP_MESSAGES = {
        "about_userbot": """
🤖 *Tentang Userbot*

Userbot adalah bot Telegram yang berjalan di akun pengguna biasa. 
Dengan userbot, Anda dapat:

• 📨 Mengirim pesan ke grup secara otomatis
• 📱 Support berbagai jenis media (foto, video, GIF)
• ⚡ Support emoji premium
• ⏱️ Pengaturan delay untuk setiap pesan
• 📊 Monitoring status pengiriman

Untuk membuat userbot, Anda harus menjadi user premium.
Hubungi @{owner} untuk info lebih lanjut.
        """,
        
        "create_userbot": """
📱 *Cara Membuat Userbot*

1. Kirim nomor telepon Anda dalam format internasional
   Contoh: +6281234567890
   
2. Masukkan kode OTP yang dikirim ke Telegram Anda
   Format: 1 2 3 4 5 (dengan spasi)
   
3. Jika diminta kata sandi 2FA, masukkan kata sandi Anda

*Note:* Pastikan nomor telepon yang digunakan sudah terdaftar di Telegram
        """,
        
        "settings_help": """
⚙️ *Pengaturan Userbot*

• 📊 Status: Mengaktifkan/menonaktifkan userbot
• 📝 Check Lists: Melihat list pesan yang akan dikirim
• ➕ Add List: Menambah pesan ke list
• 📨 Send to RC: Mengirim pesan ke recent chats
• 👥 Add Groups: Menambah grup tujuan
• 📋 List Groups: Melihat list grup tujuan
• 🗑️ Delete Group: Menghapus grup dari list
• 📥 Join Group: Join ke grup baru
• ⏱️ Set Delay: Mengatur delay antar pesan
• ❌ Delete List: Menghapus pesan dari list
• 🏠 Home: Kembali ke menu utama
        """
    }

    @classmethod
    def get_user_limits(cls, access_type: str) -> dict:
        """Get user limits based on access type"""
        return cls.PREMIUM_FEATURES.get(access_type, cls.PREMIUM_FEATURES["regular"])

    @classmethod
    def format_error(cls, error_key: str, **kwargs) -> str:
        """Format error message with parameters"""
        return cls.ERROR_MESSAGES.get(error_key, "❌ Terjadi kesalahan.").format(**kwargs)

    @classmethod
    def format_success(cls, success_key: str, **kwargs) -> str:
        """Format success message with parameters"""
        return cls.SUCCESS_MESSAGES.get(success_key, "✅ Berhasil!").format(**kwargs)

    @classmethod
    def format_help(cls, help_key: str) -> str:
        """Format help message with parameters"""
        return cls.HELP_MESSAGES.get(help_key, "").format(owner=cls.OWNER_USERNAME)

    @classmethod
    def is_admin(cls, user_id: int) -> bool:
        """Check if user is admin"""
        return user_id == cls.ADMIN_ID